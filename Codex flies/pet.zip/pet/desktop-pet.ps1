﻿[CmdletBinding()]
param(
    [switch]$ExportPreview,
    [string]$PreviewPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Speech

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$headPath = Join-Path $root 'assets\head-cutout.png'
$sourcePath = Join-Path $root 'assets\portrait-source.jpg'

if (-not (Test-Path -LiteralPath $headPath)) {
    & (Join-Path $root 'scripts\build-assets.ps1') -Source $sourcePath -OutFile $headPath | Out-Null
}
if ([string]::IsNullOrWhiteSpace($PreviewPath)) {
    $PreviewPath = Join-Path $root 'assets\pet-preview.png'
}

function New-FrozenBrush {
    param([string]$Hex)

    $brush = [System.Windows.Media.SolidColorBrush]::new(
        [System.Windows.Media.ColorConverter]::ConvertFromString($Hex)
    )
    $brush.Freeze()
    return $brush
}

function New-FrozenPen {
    param(
        [string]$Hex,
        [double]$Thickness
    )

    $pen = [System.Windows.Media.Pen]::new((New-FrozenBrush $Hex), $Thickness)
    $pen.StartLineCap = [System.Windows.Media.PenLineCap]::Round
    $pen.EndLineCap = [System.Windows.Media.PenLineCap]::Round
    $pen.LineJoin = [System.Windows.Media.PenLineJoin]::Round
    $pen.Freeze()
    return $pen
}

function New-FrozenGeometry {
    param([string]$PathData)

    $geometry = [System.Windows.Media.Geometry]::Parse($PathData)
    $geometry.Freeze()
    return $geometry
}

$colors = @{
    Ink = '#263042'
    InkSoft = '#52647B'
    Shirt = '#B8C9E2'
    ShirtLight = '#D8E2F0'
    ShirtStripe = '#F4F7FB'
    Jeans = '#24344F'
    JeansLight = '#3A4F72'
    JeansDark = '#17243A'
    Skin = '#D7A486'
    SkinLight = '#E8B99B'
    Shoe = '#17202C'
    ShoeLight = '#344257'
    Shadow = '#5A3348'
    Blush = '#E58F8B'
}

$brushes = @{}
foreach ($entry in $colors.GetEnumerator()) {
    $brushes[$entry.Key] = New-FrozenBrush $entry.Value
}

$shadowBrush = [System.Windows.Media.SolidColorBrush]::new(
    [System.Windows.Media.Color]::FromArgb(48, 71, 49, 64)
)
$shadowBrush.Freeze()
$groundBrush = [System.Windows.Media.SolidColorBrush]::new(
    [System.Windows.Media.Color]::FromArgb(35, 28, 48, 66)
)
$groundBrush.Freeze()
$blushBrush = [System.Windows.Media.SolidColorBrush]::new(
    [System.Windows.Media.Color]::FromArgb(105, 229, 128, 128)
)
$blushBrush.Freeze()

$headImage = [System.Windows.Media.Imaging.BitmapImage]::new()
$headImage.BeginInit()
$headImage.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
$headImage.UriSource = [System.Uri]::new($headPath)
$headImage.EndInit()
$headImage.Freeze()

function Add-PetDrawing {
    param(
        [System.Windows.Media.DrawingContext]$Context,
        [double]$Phase,
        [double]$Reaction,
        [double]$Facing = 1.0,
        [double]$Moving = 0.0
    )

    $breath = [Math]::Sin($Phase) * 1.35
    $bounce = -$Reaction * 15
    $gait = [Math]::Sin($Phase * 2.1) * $Moving
    $headBob = $breath - ($Reaction * 2.5) + ($gait * 1.1)
    $bodyShift = ([Math]::Sin($Phase * 0.53) * 1.15) + ($gait * 2.1)

    $Context.PushTransform(
        [System.Windows.Media.TranslateTransform]::new($bodyShift, $breath + $bounce)
    )
    if ($Facing -lt 0) {
        $Context.PushTransform([System.Windows.Media.ScaleTransform]::new(-1, 1, 150, 120))
    }

    $Context.DrawEllipse($shadowBrush, $null, [System.Windows.Point]::new(169, 205), 111, 13)
    $Context.DrawEllipse($groundBrush, $null, [System.Windows.Point]::new(65, 191), 24, 6)
    $Context.DrawEllipse($groundBrush, $null, [System.Windows.Point]::new(132, 191), 24, 6)

    # Far leg: the thigh drops under the hip and the calf folds backward.
    $farThigh = New-FrozenGeometry 'M166,134 C184,131 199,142 205,159 L194,178 L165,171 L154,150 Z'
    $farShin = New-FrozenGeometry 'M187,159 C210,157 234,167 252,182 L246,196 L218,192 L185,177 Z'
    $Context.DrawGeometry($brushes.Jeans, (New-FrozenPen $colors.JeansDark 2), $farThigh)
    $Context.DrawGeometry($brushes.JeansLight, (New-FrozenPen $colors.JeansDark 2), $farShin)
    $Context.DrawLine(
        (New-FrozenPen $colors.JeansDark 1.8),
        [System.Windows.Point]::new(181, 167),
        [System.Windows.Point]::new(197, 181)
    )

    # Near leg is offset forward so both kneeling supports remain readable.
    $nearThigh = New-FrozenGeometry 'M147,139 C165,135 181,145 188,162 L177,181 L147,174 C139,162 139,148 147,139 Z'
    $nearShin = New-FrozenGeometry 'M169,165 C192,163 216,173 236,188 L229,202 L203,197 L166,182 Z'
    $Context.DrawGeometry($brushes.JeansLight, (New-FrozenPen $colors.JeansDark 2), $nearThigh)
    $Context.DrawGeometry($brushes.Jeans, (New-FrozenPen $colors.JeansDark 2), $nearShin)

    # Far arm reaches past the face to the floor.
    $farArm = New-FrozenGeometry 'M96,107 C76,118 63,142 58,165 L74,177 C80,156 88,141 106,128 Z'
    $Context.DrawGeometry($brushes.Shirt, (New-FrozenPen $colors.InkSoft 1.6), $farArm)
    $Context.DrawLine(
        (New-FrozenPen $colors.ShirtStripe 1),
        [System.Windows.Point]::new(87, 115),
        [System.Windows.Point]::new(68, 171)
    )

    # Horizontal shirt torso connects the raised shoulders to the kneeling hips.
    $torso = New-FrozenGeometry 'M90,101 C116,89 143,101 172,124 C193,140 195,155 188,167 C158,174 128,164 101,143 C85,131 82,112 90,101 Z'
    $Context.DrawGeometry($brushes.Shirt, (New-FrozenPen $colors.InkSoft 2), $torso)

    $Context.PushClip($torso)
    for ($x = 94; $x -le 185; $x += 9) {
        $Context.DrawLine(
            (New-FrozenPen $colors.ShirtStripe 0.8),
            [System.Windows.Point]::new($x, 94),
            [System.Windows.Point]::new($x - 10, 176)
        )
    }
    $Context.Pop()

    # Shirt opening, collar, and a few visible buttons.
    $Context.DrawLine(
        (New-FrozenPen $colors.InkSoft 1.2),
        [System.Windows.Point]::new(111, 104),
        [System.Windows.Point]::new(124, 153)
    )
    $leftCollar = New-FrozenGeometry 'M96,105 L113,107 L103,121 Z'
    $rightCollar = New-FrozenGeometry 'M119,102 L110,112 L128,116 Z'
    $Context.DrawGeometry($brushes.ShirtLight, (New-FrozenPen $colors.InkSoft 1), $leftCollar)
    $Context.DrawGeometry($brushes.ShirtLight, (New-FrozenPen $colors.InkSoft 1), $rightCollar)
    foreach ($y in @(119, 134, 148)) {
        $Context.DrawEllipse($brushes.ShirtLight, $null, [System.Windows.Point]::new(120 + (($y - 119) * 0.2), $y), 1.7, 1.7)
    }

    # Jeans waistband and back pocket anchor the shirt over the folded legs.
    $hips = New-FrozenGeometry 'M162,143 C181,137 198,145 205,159 L198,176 L158,166 C156,158 157,149 162,143 Z'
    $Context.DrawGeometry($brushes.Jeans, (New-FrozenPen $colors.JeansDark 1.8), $hips)
    $Context.DrawLine(
        (New-FrozenPen $colors.JeansDark 1.8),
        [System.Windows.Point]::new(160, 149),
        [System.Windows.Point]::new(199, 163)
    )
    $Context.DrawLine(
        (New-FrozenPen $colors.JeansDark 1.2),
        [System.Windows.Point]::new(180, 150),
        [System.Windows.Point]::new(193, 155)
    )

    # The source photo remains visible as the face. It is scaled down and
    # overlapped with the illustrated neck and collar.
    $Context.DrawEllipse($brushes.Skin, $null, [System.Windows.Point]::new(101, 118), 19, 21)
    $headRect = [System.Windows.Rect]::new(39, 17 + $headBob, 106, 134)
    $Context.DrawImage($headImage, $headRect)

    # Near arm stays in front of the torso; both palms are planted.
    $nearArm = New-FrozenGeometry 'M119,105 C143,117 151,144 143,165 L126,174 C130,154 124,135 106,120 Z'
    $Context.DrawGeometry($brushes.ShirtLight, (New-FrozenPen $colors.InkSoft 1.7), $nearArm)
    $Context.DrawLine(
        (New-FrozenPen $colors.ShirtStripe 1.1),
        [System.Windows.Point]::new(130, 118),
        [System.Windows.Point]::new(130, 163)
    )
    $Context.DrawEllipse($brushes.Skin, (New-FrozenPen $colors.InkSoft 1.2),
        [System.Windows.Point]::new(64, 185), 18, 9)
    $Context.DrawEllipse($brushes.SkinLight, (New-FrozenPen $colors.InkSoft 1.2),
        [System.Windows.Point]::new(133, 181), 18, 9)

    # Fingers read as separate supports on the desktop.
    foreach ($offset in @(-6, 0, 6)) {
        $Context.DrawLine(
            (New-FrozenPen $colors.Skin 2.2),
            [System.Windows.Point]::new(64 + $offset, 187),
            [System.Windows.Point]::new(67 + $offset, 196)
        )
        $Context.DrawLine(
            (New-FrozenPen $colors.Skin 2.2),
            [System.Windows.Point]::new(133 + $offset, 183),
            [System.Windows.Point]::new(136 + $offset, 193)
        )
    }

    # Shoes at the ends of the folded calves reinforce the kneeling pose.
    $backShoe = New-FrozenGeometry 'M242,177 C257,177 268,186 272,197 L266,209 L246,205 L233,193 Z'
    $frontShoe = New-FrozenGeometry 'M220,188 C235,189 246,198 249,208 L240,218 L221,212 L209,201 Z'
    $Context.DrawGeometry($brushes.Shoe, (New-FrozenPen $colors.Ink 1.4), $backShoe)
    $Context.DrawGeometry($brushes.ShoeLight, (New-FrozenPen $colors.Ink 1.4), $frontShoe)
    $Context.DrawLine(
        (New-FrozenPen $colors.ShoeLight 2),
        [System.Windows.Point]::new(244, 188),
        [System.Windows.Point]::new(266, 198)
    )

    # A tiny blush pulse gives the click response a friendly read.
    if ($Reaction -gt 0.05) {
        $Context.DrawEllipse($blushBrush, $null, [System.Windows.Point]::new(78, 91 + $headBob), 7, 3.3)
        $Context.DrawEllipse($blushBrush, $null, [System.Windows.Point]::new(120, 91 + $headBob), 7, 3.3)
    }

    if ($Facing -lt 0) {
        $Context.Pop()
    }
    $Context.Pop()
}

function Export-PetPreview {
    param([string]$Path)

    $visual = [System.Windows.Media.DrawingVisual]::new()
    $context = $visual.RenderOpen()
    Add-PetDrawing -Context $context -Phase 0.65 -Reaction 0
    $context.Close()

    $bitmap = [System.Windows.Media.Imaging.RenderTargetBitmap]::new(
        300,
        240,
        96,
        96,
        [System.Windows.Media.PixelFormats]::Pbgra32
    )
    $bitmap.Render($visual)

    $directory = Split-Path -Parent $Path
    New-Item -ItemType Directory -Force -Path $directory | Out-Null
    $stream = [System.IO.File]::Create($Path)
    try {
        $encoder = [System.Windows.Media.Imaging.PngBitmapEncoder]::new()
        $encoder.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($bitmap))
        $encoder.Save($stream)
    }
    finally {
        $stream.Dispose()
    }

    Write-Output $Path
}

if ($ExportPreview) {
    Export-PetPreview -Path $PreviewPath
    return
}

$visual = [System.Windows.Media.DrawingVisual]::new()
$window = [System.Windows.Window]::new()
$window.Title = 'Mian Bao Desktop Pet'
$window.Width = 300
$window.Height = 240
$window.WindowStyle = [System.Windows.WindowStyle]::None
$window.ResizeMode = [System.Windows.ResizeMode]::NoResize
$window.AllowsTransparency = $true
$window.Background = [System.Windows.Media.Brushes]::Transparent
$window.ShowInTaskbar = $false
$window.Topmost = $true

$hostVisual = [System.Windows.Media.VisualBrush]::new($visual)
$hostVisual.Stretch = [System.Windows.Media.Stretch]::None
$hostVisual.AlignmentX = [System.Windows.Media.AlignmentX]::Left
$hostVisual.AlignmentY = [System.Windows.Media.AlignmentY]::Top

$surface = [System.Windows.Controls.Border]::new()
$surface.Background = $hostVisual
$surface.ToolTip = '拖动我；点一下会跳；右键打开菜单'
$window.Content = $surface

$workArea = [System.Windows.SystemParameters]::WorkArea
$window.Left = [Math]::Max(0, $workArea.Right - $window.Width - 18)
$window.Top = [Math]::Max(0, $workArea.Bottom - $window.Height - 10)

$script:phase = 0.0
$script:reaction = 0.0
$script:lastRender = [DateTime]::UtcNow
$script:dragging = $false
$script:dragMoved = $false
$script:dragStartScreen = [System.Windows.Point]::new(0, 0)
$script:dragStartWindow = [System.Windows.Point]::new(0, 0)
$script:autoCrawl = $true
$script:facing = 1.0
$script:moving = 0.0

$script:speech = $null
try {
    $speechCandidate = [System.Speech.Synthesis.SpeechSynthesizer]::new()
    $chineseVoices = @(
        $speechCandidate.GetInstalledVoices() |
            Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.Name -eq 'zh-CN' }
    )
    $preferredVoice = $chineseVoices |
        Where-Object { $_.VoiceInfo.Name -like '*Kangkang*' } |
        Select-Object -First 1
    if ($null -eq $preferredVoice -and $chineseVoices.Count -gt 0) {
        $preferredVoice = $chineseVoices[0]
    }
    if ($null -ne $preferredVoice) {
        $speechCandidate.SelectVoice($preferredVoice.VoiceInfo.Name)
    }
    $speechCandidate.Rate = 0
    $speechCandidate.Volume = 100
    $script:speech = $speechCandidate
}
catch {
    if ($null -ne $speechCandidate) {
        $speechCandidate.Dispose()
    }
    $script:speech = $null
}

function Update-PetMotion {
    param([double]$Elapsed)

    $script:moving = [Math]::Max(0.0, $script:moving - ($Elapsed * 2.4))
    if (
        -not $script:autoCrawl -or
        $script:dragging -or
        $window.ContextMenu.IsOpen
    ) {
        return
    }

    $cursor = [System.Windows.Forms.Cursor]::Position
    $cursorInWindow = $window.PointFromScreen(
        [System.Windows.Point]::new($cursor.X, $cursor.Y)
    )
    $deltaX = $cursorInWindow.X - ($window.Width / 2)
    $deltaY = $cursorInWindow.Y - ($window.Height * 0.62)

    if ([Math]::Abs($deltaX) -gt 8) {
        if ($deltaX -gt 0) {
            $script:facing = -1.0
        }
        else {
            $script:facing = 1.0
        }
    }

    $distance = [Math]::Sqrt(($deltaX * $deltaX) + ($deltaY * $deltaY))
    if ($distance -le 72) {
        return
    }

    $speed = 58.0
    $travel = [Math]::Min($speed * $Elapsed, $distance - 68)
    if ($travel -le 0) {
        return
    }

    $stepX = ($deltaX / $distance) * $travel
    $stepY = ($deltaY / $distance) * $travel

    $minLeft = $workArea.Left + 4
    $maxLeft = $workArea.Right - $window.Width - 4
    $minTop = $workArea.Top + 4
    $maxTop = $workArea.Bottom - $window.Height - 4

    $window.Left = [Math]::Max($minLeft, [Math]::Min($maxLeft, $window.Left + $stepX))
    $window.Top = [Math]::Max($minTop, [Math]::Min($maxTop, $window.Top + $stepY))
    $script:moving = 1.0
}

function Render-Pet {
    $now = [DateTime]::UtcNow
    $elapsed = [Math]::Min(0.08, [Math]::Max(0.001, ($now - $script:lastRender).TotalSeconds))
    $script:lastRender = $now
    Update-PetMotion -Elapsed $elapsed
    $script:phase += $elapsed * (2.15 + ($script:moving * 6.0))
    $script:reaction *= [Math]::Pow(0.08, $elapsed)

    $context = $visual.RenderOpen()
    Add-PetDrawing `
        -Context $context `
        -Phase $script:phase `
        -Reaction $script:reaction `
        -Facing $script:facing `
        -Moving $script:moving
    $context.Close()
}

function Invoke-PetHop {
    param([double]$Strength = 1.0)

    $script:reaction = [Math]::Min(1.25, $script:reaction + $Strength)
}

function Invoke-PetSpeech {
    if ($null -eq $script:speech) {
        return
    }

    try {
        $script:speech.SpeakAsyncCancelAll()
        [void]$script:speech.SpeakAsync('宝宝，我爱你')
    }
    catch {
        # Speech should never stop the interaction if the system voice is busy.
    }
}

$timer = [System.Windows.Threading.DispatcherTimer]::new()
$timer.Interval = [TimeSpan]::FromMilliseconds(32)
$timer.Add_Tick({
    Render-Pet
})

$hopItem = [System.Windows.Controls.MenuItem]::new()
$hopItem.Header = '跳一下'
$hopItem.Add_Click({ Invoke-PetHop -Strength 1.0 })

$nudgeItem = [System.Windows.Controls.MenuItem]::new()
$nudgeItem.Header = '开心一下'
$nudgeItem.Add_Click({ Invoke-PetHop -Strength 0.7 })

$crawlItem = [System.Windows.Controls.MenuItem]::new()
$crawlItem.Header = '自动爬行'
$crawlItem.IsCheckable = $true
$crawlItem.IsChecked = $true
$crawlItem.Add_Click({
    $script:autoCrawl = $crawlItem.IsChecked
})

$startupKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$startupValueName = 'CodexDesktopPet'
$launcherPath = Join-Path $root '桌面宠物.exe'
$startupCommand = if (Test-Path -LiteralPath $launcherPath) {
    '"' + $launcherPath + '" --startup'
}
else {
    'wscript.exe "' + (Join-Path $root 'start-pet.vbs') + '"'
}
$startupEnabled = $false
try {
    $startupProperty = Get-ItemProperty -Path $startupKey -Name $startupValueName -ErrorAction Stop
    $startupEnabled = -not [string]::IsNullOrWhiteSpace(
        $startupProperty.PSObject.Properties[$startupValueName].Value
    )
}
catch {
    $startupEnabled = $false
}

$startupItem = [System.Windows.Controls.MenuItem]::new()
$startupItem.Header = '开机自动启动'
$startupItem.IsCheckable = $true
$startupItem.IsChecked = $startupEnabled
$startupItem.Add_Click({
    try {
        if ($startupItem.IsChecked) {
            New-ItemProperty `
                -Path $startupKey `
                -Name $startupValueName `
                -Value $startupCommand `
                -PropertyType String `
                -Force | Out-Null
        }
        else {
            Remove-ItemProperty `
                -Path $startupKey `
                -Name $startupValueName `
                -ErrorAction SilentlyContinue
        }
    }
    catch {
        $startupItem.IsChecked = -not $startupItem.IsChecked
    }
})

$topmostItem = [System.Windows.Controls.MenuItem]::new()
$topmostItem.Header = '始终置顶'
$topmostItem.IsCheckable = $true
$topmostItem.IsChecked = $true
$topmostItem.Add_Click({
    $window.Topmost = $topmostItem.IsChecked
})

$exitItem = [System.Windows.Controls.MenuItem]::new()
$exitItem.Header = '退出'
$exitItem.Add_Click({ $window.Close() })

$menu = [System.Windows.Controls.ContextMenu]::new()
$menu.Items.Add($hopItem) | Out-Null
$menu.Items.Add($nudgeItem) | Out-Null
$menu.Items.Add([System.Windows.Controls.Separator]::new()) | Out-Null
$menu.Items.Add($crawlItem) | Out-Null
$menu.Items.Add($startupItem) | Out-Null
$menu.Items.Add($topmostItem) | Out-Null
$menu.Items.Add($exitItem) | Out-Null
$window.ContextMenu = $menu

$window.Add_MouseLeftButtonDown({
    param($sender, $eventArgs)

    $script:dragging = $true
    $script:dragMoved = $false
    $script:dragStartScreen = $sender.PointToScreen($eventArgs.GetPosition($sender))
    $script:dragStartWindow = [System.Windows.Point]::new($sender.Left, $sender.Top)
    $sender.CaptureMouse() | Out-Null
    $eventArgs.Handled = $true
})

$window.Add_MouseMove({
    param($sender, $eventArgs)

    if (-not $script:dragging) {
        return
    }

    $screenPoint = $sender.PointToScreen($eventArgs.GetPosition($sender))
    $deltaX = $screenPoint.X - $script:dragStartScreen.X
    $deltaY = $screenPoint.Y - $script:dragStartScreen.Y

    if ([Math]::Abs($deltaX) + [Math]::Abs($deltaY) -gt 3) {
        $script:dragMoved = $true
    }

    $sender.Left = $script:dragStartWindow.X + $deltaX
    $sender.Top = $script:dragStartWindow.Y + $deltaY
})

$window.Add_MouseLeftButtonUp({
    param($sender, $eventArgs)

    $sender.ReleaseMouseCapture()
    $script:dragging = $false
    if (-not $script:dragMoved) {
        Invoke-PetHop -Strength 0.85
        Invoke-PetSpeech
    }
    $eventArgs.Handled = $true
})

$window.Add_Closed({
    $timer.Stop()
    if ($null -ne $script:speech) {
        $script:speech.Dispose()
    }
})

$window.Add_Loaded({
    Render-Pet
    $timer.Start()
})

[void]$window.ShowDialog()
